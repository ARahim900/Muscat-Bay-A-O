const DataSourceIndicator = () => {
  return (
    <span className="text-xs px-2 py-1 rounded-full bg-indigo-600/20 text-indigo-200">Using Meter Readings Data</span>
  )
}

export default DataSourceIndicator
