"use client"

import { useState, useEffect } from "react"
import { processDataFromTSV, type ProcessedData } from "@/utils/data-processor"

export default function DataIntegration() {
  const [data, setData] = useState<ProcessedData | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch("/data/meter-readings.txt")
        const text = await response.text()
        const processedData = processDataFromTSV(text)
        setData(processedData)
        setIsLoading(false)
      } catch (error) {
        console.error("Error loading data:", error)
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  if (isLoading || !data) {
    return <div>Loading data...</div>
  }

  // Get the latest period
  const latestPeriod = data.periods[data.periods.length - 1]
  const stats = data.stats[latestPeriod]

  // Calculate total consumption by type
  const consumptionByType = Object.entries(stats.typeConsumption)
    .filter(([_, value]) => (value as number) > 0)
    .sort((a, b) => (b[1] as number) - (a[1] as number))
    .map(([type, value]) => ({
      name: type,
      value: value as number,
    }))

  // Calculate zone performance
  const zonePerformance = Object.entries(stats.zoneStats)
    .filter(([_, zoneStats]) => (zoneStats as any).bulkReading > 0)
    .sort((a, b) => (b[1] as any).lossPercent - (a[1] as any).lossPercent)
    .map(([zone, zoneStats]) => ({
      name: zone,
      loss: (zoneStats as any).lossPercent,
      volume: (zoneStats as any).bulkReading,
    }))

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Data Integration</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow border border-gray-200 dark:border-gray-700">
          <h3 className="text-md font-medium mb-2">Top Consumption Types</h3>
          <ul className="space-y-2">
            {consumptionByType.slice(0, 5).map((item) => (
              <li key={item.name} className="flex justify-between">
                <span>{item.name}</span>
                <span className="font-medium">{item.value.toLocaleString()} m³</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow border border-gray-200 dark:border-gray-700">
          <h3 className="text-md font-medium mb-2">Zones with Highest Loss</h3>
          <ul className="space-y-2">
            {zonePerformance.slice(0, 5).map((item) => (
              <li key={item.name} className="flex justify-between">
                <span>{item.name}</span>
                <span
                  className={`font-medium ${
                    item.loss > 20
                      ? "text-red-600 dark:text-red-400"
                      : item.loss > 10
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-green-600 dark:text-green-400"
                  }`}
                >
                  {item.loss.toFixed(1)}%
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow border border-gray-200 dark:border-gray-700">
        <h3 className="text-md font-medium mb-2">Summary for {latestPeriod}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Supply</p>
            <p className="text-xl font-bold">{stats.l1Supply.toLocaleString()} m³</p>
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Consumption</p>
            <p className="text-xl font-bold">{stats.l3Volume.toLocaleString()} m³</p>
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Loss</p>
            <p className="text-xl font-bold">{stats.totalLoss.toLocaleString()} m³</p>
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Loss Percentage</p>
            <p className="text-xl font-bold">{stats.totalLossPercent.toFixed(1)}%</p>
          </div>
        </div>
      </div>
    </div>
  )
}
