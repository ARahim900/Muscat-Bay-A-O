"use client"

import type React from "react"

import { useState, useRef } from "react"
import { FileText, UploadCloud, CheckCircle, XCircle } from "lucide-react"
import { processDataFromTSV } from "@/utils/data-processor"

interface AdminDataUploaderProps {
  onDataProcessed: (data: any) => void
}

export default function AdminDataUploader({ onDataProcessed }: AdminDataUploaderProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [uploadError, setUploadError] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Basic validation for TSV/TXT MIME types
      if (
        file.type === "text/tab-separated-values" ||
        file.type === "text/plain" ||
        file.name.endsWith(".tsv") ||
        file.name.endsWith(".txt")
      ) {
        setUploadedFile(file)
        setUploadStatus("idle")
        setUploadError("")
      } else {
        setUploadedFile(null)
        setUploadStatus("error")
        setUploadError("Invalid file type. Please upload a .tsv or .txt file.")
      }
    }
  }

  const handleUseDefaultData = async () => {
    try {
      setUploadStatus("loading")
      setUploadError("")

      // Fetch the default data file
      const response = await fetch("/data/meter-readings.txt")
      const fileContent = await response.text()

      // Process the data
      const processedData = processDataFromTSV(fileContent)

      // Pass the processed data to the parent component
      onDataProcessed(processedData)

      setUploadStatus("success")

      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    } catch (err) {
      console.error("Error processing default data:", err)
      setUploadStatus("error")
      setUploadError(`Error processing default data: ${err.message}`)
    }
  }

  const handleFileUpload = () => {
    if (!uploadedFile) {
      setUploadError("Please select a file first.")
      setUploadStatus("error")
      return
    }

    setUploadStatus("loading")
    setUploadError("")

    const reader = new FileReader()

    reader.onload = (event) => {
      try {
        const fileContent = event.target?.result as string
        const processedData = processDataFromTSV(fileContent)

        // Pass the processed data to the parent component
        onDataProcessed(processedData)

        setUploadStatus("success")
        setUploadedFile(null)

        // Clear the file input
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      } catch (err) {
        console.error("Error processing uploaded file:", err)
        setUploadStatus("error")
        setUploadError(`Error processing file: ${err.message}`)
      }
    }

    reader.onerror = () => {
      setUploadStatus("error")
      setUploadError("Error reading the selected file.")
    }

    reader.readAsText(uploadedFile)
  }

  return (
    <div className="space-y-6">
      {/* Instructions */}
      <div className="prose prose-sm dark:prose-invert max-w-none p-4 border dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800/50">
        <h3 className="flex items-center">
          <FileText size={18} className="mr-2 text-indigo-500" />
          File Format Instructions
        </h3>
        <p>
          Upload a Tab-Separated Value (<code>.tsv</code> or <code>.txt</code>) file containing the meter reading data.
          The file must follow the specific format outlined in the "Data Upload File Format Guide".
        </p>
        <p>Key requirements include:</p>
        <ul>
          <li>UTF-8 encoding</li>
          <li>Tab characters separating columns</li>
          <li>A specific header row (see guide for details)</li>
          <li>Numerical readings without commas or units</li>
        </ul>
      </div>

      {/* File Input and Upload Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-4">
        <label htmlFor="file-upload" className="sr-only">
          Choose file
        </label>
        <input
          ref={fileInputRef}
          id="file-upload"
          type="file"
          accept=".tsv,.txt,text/tab-separated-values,text/plain"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 dark:text-gray-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900 cursor-pointer"
        />
        <div className="flex gap-2">
          <button
            onClick={handleFileUpload}
            disabled={!uploadedFile || uploadStatus === "loading"}
            className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
          >
            <UploadCloud size={18} className="mr-2" />
            {uploadStatus === "loading" ? "Processing..." : "Upload & Process File"}
          </button>
          <button
            onClick={handleUseDefaultData}
            disabled={uploadStatus === "loading"}
            className="inline-flex items-center justify-center px-4 py-2 border border-indigo-600 text-sm font-medium rounded-md shadow-sm text-indigo-600 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap dark:bg-transparent dark:text-indigo-400 dark:border-indigo-400 dark:hover:bg-indigo-950"
          >
            Use Default Data
          </button>
        </div>
      </div>

      {/* Status Messages */}
      {uploadStatus === "success" && (
        <div className="p-3 rounded-md bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-700">
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 text-green-500 dark:text-green-400 mr-2" aria-hidden="true" />
            <p className="text-sm font-medium text-green-800 dark:text-green-200">
              Data processed successfully! Dashboard updated.
            </p>
          </div>
        </div>
      )}
      {uploadStatus === "error" && (
        <div className="p-3 rounded-md bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700">
          <div className="flex items-center">
            <XCircle className="h-5 w-5 text-red-500 dark:text-red-400 mr-2" aria-hidden="true" />
            <p className="text-sm font-medium text-red-800 dark:text-red-200">
              {uploadError || "An unknown error occurred during upload."}
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
