import DataDisplay from "@/components/data-display"

export default function DataViewPage() {
  return (
    <div className="max-w-screen-xl mx-auto p-4 sm:p-6 lg:p-8">
      <h1 className="text-2xl font-bold mb-6">Water Analytics Data</h1>
      <DataDisplay />
    </div>
  )
}
