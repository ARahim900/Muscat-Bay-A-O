"use client"

import { useEffect, useState } from "react"
import DashboardApp from "@/components/dashboard-app"

export default function Home() {
  const [isDataReady, setIsDataReady] = useState(false)
  const [dataError, setDataError] = useState(null)

  useEffect(() => {
    // Check if the data file exists
    fetch("/data/meter-readings.txt")
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Failed to load data file: ${response.status} ${response.statusText}`)
        }
        return response.text()
      })
      .then((text) => {
        console.log("Data file loaded successfully. First 100 chars:", text.substring(0, 100))
        setIsDataReady(true)
      })
      .catch((error) => {
        console.error("Error loading data file:", error)
        setDataError(error.message)
        // Proceed anyway, the dashboard will use sample data
        setIsDataReady(true)
      })
  }, [])

  if (!isDataReady) {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-gray-700 dark:text-gray-300">Loading Water Analytics Data...</p>
        </div>
      </div>
    )
  }

  if (dataError) {
    console.warn("Proceeding with sample data due to error:", dataError)
  }

  return <DashboardApp />
}
