export default function PublicPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Public Resources</h1>
      <p>This page ensures the public directory is accessible.</p>
      <p className="mt-4">
        <a href="/data/meter-readings.txt" className="text-blue-500 hover:underline">
          View Meter Readings Data
        </a>
      </p>
    </div>
  )
}
