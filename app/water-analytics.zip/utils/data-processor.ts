/**
 * Utility functions for processing meter reading data
 */

export interface MeterReading {
  label: string
  meterLabel: string
  acctNum: string
  zone: string
  type: string
  parentMeter: string
  readings: Record<string, number>
}

export interface ProcessedData {
  meters: MeterReading[]
  periods: string[]
  uniqueZones: string[]
  uniqueTypes: string[]
  stats: Record<string, any>
}

/**
 * Processes raw TSV data into a structured format
 */
export function processDataFromTSV(tsvText: string): ProcessedData {
  const lines = tsvText.trim().split("\n")
  const headers = lines[0].split("\t").map((h) => h.trim())

  // Extract column indices
  const labelIndex = headers.indexOf("Label")
  const meterLabelIndex = headers.indexOf("Meter Label")
  const acctNumIndex = headers.indexOf("Acct #")
  const zoneIndex = headers.indexOf("Zone")
  const typeIndex = headers.indexOf("Type")
  const parentMeterIndex = headers.indexOf("Parent Meter")

  // Extract period columns (e.g., Jan-24, Feb-24)
  const periodIndices: Record<string, number> = {}
  const periods: string[] = []

  headers.forEach((header, index) => {
    if (/^\w{3}-\d{2}$/.test(header)) {
      periodIndices[header] = index
      periods.push(header)
    }
  })

  // Sort periods chronologically
  periods.sort((a, b) => {
    const [m1, y1] = a.split("-")
    const [m2, y2] = b.split("-")
    const yearDiff = Number.parseInt(y1) - Number.parseInt(y2)
    if (yearDiff !== 0) return yearDiff

    const monthOrder = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return monthOrder.indexOf(m1) - monthOrder.indexOf(m2)
  })

  // Process meter data
  const meters: MeterReading[] = []

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split("\t").map((v) => v.trim())

    if (values.length !== headers.length) continue

    const meter: MeterReading = {
      label: values[labelIndex],
      meterLabel: values[meterLabelIndex],
      acctNum: values[acctNumIndex] || "N/A",
      zone: values[zoneIndex] || "Unassigned",
      type: values[typeIndex] || "Unknown",
      parentMeter: values[parentMeterIndex] || null,
      readings: {},
    }

    // Process readings for each period
    Object.entries(periodIndices).forEach(([period, index]) => {
      const reading = Number.parseFloat(values[index] || "0")
      meter.readings[period] = isNaN(reading) ? 0 : reading
    })

    meters.push(meter)
  }

  // Extract unique zones and types
  const uniqueZones = [...new Set(meters.filter((m) => m.zone && m.zone !== "Unassigned").map((m) => m.zone))]
  const uniqueTypes = [
    ...new Set(meters.filter((m) => m.type && m.type !== "Unknown" && m.type !== "BULK").map((m) => m.type)),
  ]

  // Calculate basic stats
  const stats = calculateStats(meters, periods)

  return {
    meters,
    periods,
    uniqueZones,
    uniqueTypes,
    stats,
  }
}

/**
 * Calculate statistics for the meter readings
 */
function calculateStats(meters: MeterReading[], periods: string[]): Record<string, any> {
  const stats: Record<string, any> = {}

  periods.forEach((period) => {
    // Find main bulk meter (L1)
    const l1Meter = meters.find((m) => m.label === "L1")
    const l1Supply = l1Meter ? l1Meter.readings[period] : 0

    // Find L2 meters
    const l2Meters = meters.filter((m) => m.label === "L2")
    const l2Volume = l2Meters.reduce((sum, m) => sum + (m.readings[period] || 0), 0)

    // Find L3 meters
    const l3Meters = meters.filter((m) => m.label === "L3")
    const l3Volume = l3Meters.reduce((sum, m) => sum + (m.readings[period] || 0), 0)

    // Calculate losses
    const totalLoss = l1Supply > 0 ? Math.max(0, l1Supply - l3Volume) : 0
    const totalLossPercent = l1Supply > 0 ? (totalLoss / l1Supply) * 100 : 0

    // Calculate zone-specific stats
    const zoneStats: Record<string, any> = {}

    // Group by zone
    const zoneGroups = meters.reduce(
      (acc, meter) => {
        if (!acc[meter.zone]) {
          acc[meter.zone] = []
        }
        acc[meter.zone].push(meter)
        return acc
      },
      {} as Record<string, MeterReading[]>,
    )

    // Calculate stats for each zone
    Object.entries(zoneGroups).forEach(([zone, zoneMeters]) => {
      const zoneBulkMeter = zoneMeters.find((m) => m.label === "L2" && m.zone === zone)
      const zoneBulkReading = zoneBulkMeter ? zoneBulkMeter.readings[period] || 0 : 0

      const zoneL3Meters = zoneMeters.filter((m) => m.label === "L3")
      const zoneL3Sum = zoneL3Meters.reduce((sum, m) => sum + (m.readings[period] || 0), 0)

      const zoneLoss = zoneBulkReading > 0 ? Math.max(0, zoneBulkReading - zoneL3Sum) : 0
      const zoneLossPercent = zoneBulkReading > 0 ? (zoneLoss / zoneBulkReading) * 100 : 0

      zoneStats[zone] = {
        bulkReading: zoneBulkReading,
        l3Sum: zoneL3Sum,
        loss: zoneLoss,
        lossPercent: zoneLossPercent,
        meterCount: zoneL3Meters.length,
      }
    })

    // Calculate consumption by type
    const typeConsumption: Record<string, number> = {}
    const uniqueTypes = [
      ...new Set(meters.filter((m) => m.type && m.type !== "Unknown" && m.type !== "BULK").map((m) => m.type)),
    ]

    uniqueTypes.forEach((type) => {
      const typeMeters = meters.filter((m) => (m.label === "L3" || m.label === "DC") && m.type === type)
      const typeVolume = typeMeters.reduce((sum, m) => sum + (m.readings[period] || 0), 0)
      typeConsumption[type] = typeVolume
    })

    stats[period] = {
      l1Supply,
      l2Volume,
      l3Volume,
      totalLoss,
      totalLossPercent,
      zoneStats,
      typeConsumption,
    }
  })

  return stats
}

/**
 * Loads data from the data file
 */
export async function loadMeterData(): Promise<ProcessedData> {
  try {
    // In a real application, this would fetch the file
    // For this example, we'll import it directly in the component
    return null
  } catch (error) {
    console.error("Error loading meter data:", error)
    throw error
  }
}
