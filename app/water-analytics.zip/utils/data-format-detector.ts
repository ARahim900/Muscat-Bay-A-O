/**
 * Utility to detect data format and help with debugging
 */

export function detectDataFormat(text) {
  if (!text) return { format: "unknown", details: "No data provided" }

  const lines = text.trim().split(/\r?\n/)
  if (lines.length < 2) return { format: "unknown", details: "Not enough lines" }

  const firstLine = lines[0]
  const secondLine = lines[1]

  // Check for common delimiters
  const tabCount = (firstLine.match(/\t/g) || []).length
  const commaCount = (firstLine.match(/,/g) || []).length
  const semicolonCount = (firstLine.match(/;/g) || []).length
  const pipeCount = (firstLine.match(/\|/g) || []).length

  const delimiters = [
    { name: "tab", count: tabCount, char: "\t" },
    { name: "comma", count: commaCount, char: "," },
    { name: "semicolon", count: semicolonCount, char: ";" },
    { name: "pipe", count: pipeCount, char: "|" },
  ].sort((a, b) => b.count - a.count)

  const mostLikelyDelimiter = delimiters[0]

  if (mostLikelyDelimiter.count === 0) {
    return { format: "unknown", details: "No common delimiters found" }
  }

  // Split by the most likely delimiter
  const headers = firstLine.split(mostLikelyDelimiter.char).map((h) => h.trim())
  const firstRow = secondLine.split(mostLikelyDelimiter.char).map((v) => v.trim())

  return {
    format:
      mostLikelyDelimiter.name === "tab"
        ? "tsv"
        : mostLikelyDelimiter.name === "comma"
          ? "csv"
          : `${mostLikelyDelimiter.name}-separated`,
    delimiter: mostLikelyDelimiter.name,
    delimiterChar: mostLikelyDelimiter.char,
    headerCount: headers.length,
    firstRowCount: firstRow.length,
    headers: headers,
    firstRowSample: firstRow.slice(0, Math.min(5, firstRow.length)),
    details: `Found ${headers.length} columns using ${mostLikelyDelimiter.name} delimiter`,
  }
}
