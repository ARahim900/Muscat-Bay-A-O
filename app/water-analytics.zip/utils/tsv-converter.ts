/**
 * Utility to preprocess TSV data
 */
export function preprocessData(tsvText) {
  if (!tsvText) return ""

  // Handle different line endings
  const normalizedText = tsvText.replace(/\r\n/g, "\n").replace(/\r/g, "\n")

  // Log the first few lines for debugging
  const lines = normalizedText.split("\n")
  console.log("First line:", lines[0])
  if (lines.length > 1) {
    console.log("Second line (first 100 chars):", lines[1].substring(0, 100))
  }

  // Check if the file might be CSV instead of TSV
  if (lines[0].includes(",") && !lines[0].includes("\t")) {
    console.log("File appears to be CSV, converting to TSV...")
    return normalizedText
      .split("\n")
      .map((line) => line.replace(/,/g, "\t"))
      .join("\n")
  }

  // Check if the file might be semicolon-separated
  if (lines[0].includes(";") && !lines[0].includes("\t")) {
    console.log("File appears to be semicolon-separated, converting to TSV...")
    return normalizedText
      .split("\n")
      .map((line) => line.replace(/;/g, "\t"))
      .join("\n")
  }

  // Check if the file might be pipe-separated
  if (lines[0].includes("|") && !lines[0].includes("\t")) {
    console.log("File appears to be pipe-separated, converting to TSV...")
    return normalizedText
      .split("\n")
      .map((line) => line.replace(/\|/g, "\t"))
      .join("\n")
  }

  return normalizedText
}
